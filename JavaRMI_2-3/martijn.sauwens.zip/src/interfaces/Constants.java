package interfaces;

public class Constants {

    /**
     * The name used to find the manager in the registry
     */
    public static final String MANAGER_NAME = "SessionManager";
}
